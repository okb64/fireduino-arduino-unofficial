#!/bin/sh

#echo "starting upload script"
#echo "Args to shell:" $*
#
# ARG 1: Path to this script.
# ARG 2: Bin File to upload
#
#path may contain \ need to change all to /
mydir="$1"
mydir="${mydir//\\/\/}"
sleep="${mydir}"/sleep.exe
RkPackageTool="${mydir}"/RkPackageTool.exe
binfile="${2//\\/\/}"
firmware="${binfile%%.bin}".img
upgrade_tool="${mydir}"/upgrade_Console_Tool.exe

function fatal() {
    echo
  echo "$1"
  shift
    echo "$@"
  exit 1
}
echo
echo "------------"
echo "Packaging..."
echo "------------"
RESULT=$("$RkPackageTool" \
  --path "${binfile}" \
  --res "${mydir}/Menu.res" \
  --firmware "${firmware}" \
  --uis "${mydir}/image.uis" \
  --masterversion "0" \
  --slaveversion "1" \
  --smallversion "11" 2>&1) \
  || fatal "Package failed:" "$RESULT"
echo "done"

"$sleep" 1

echo
echo "------------"
echo "Uploading..."
echo "------------"

count=0
while true; do
    echo -en ">"
  ((count=count+1))
  if [[ $count -gt 40 ]]; then
      echo
    fi
  "$sleep" 0.5
done &
dot_pid=$!

RESULT=$("$upgrade_tool" UF "${firmware}" 2>&1)

if [[ $? -ne 0 ]]; then
  kill $dot_pid
  fatal "Upgrade failed:" "$RESULT"
else
  kill $dot_pid
  echo -e "\ndone"
fi
