/*
 * Record.h
 *
 *  Created on: 2016年9月19日
 *      Author: huangab
 */

#ifndef _RECORD_H_
#define _RECORD_H_


#include "Arduino.h"

// record status
typedef enum
{
	RECORD_INIT = 0,
	RECORD_PREPARE,
	RECORD_BEING ,
	RECORD_PAUSE ,
	RECORD_STOP ,
}RecordStatus;


typedef enum
{
	Record_MIC,         // MIC
}Record_Source;

class RecordClass {
public:
	RecordClass() { };
public:
	void 	begin(void);
//	void 	begin(Record_Source st);
	void    start(unsigned short *filename);
	void    pause(void);
	void    resume(void);
	void    stop(void);
	RecordStatus    getStatus(void);
	void	end(void);
	operator bool();

public:
	bool init_flag = false;
	Record_Source _st;
};

extern RecordClass Record;


#endif /* ARDUINO_LIBRARIES_RECORD_RECORD_H_ */
