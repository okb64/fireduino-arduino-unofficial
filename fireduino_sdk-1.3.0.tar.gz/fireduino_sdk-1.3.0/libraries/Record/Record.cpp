/*
 * Record.cpp
 *
 *  Created on: 2016年9月19日
 *      Author: huangab
 */


#include <ard_record.h>
#include <string.h>
#include <wchar.h>
#include "Record.h"

void RecordClass::begin(void){
	_st =  Record_MIC;
	if(init_flag == false)
	{
		if(ard_record_init(_st) == 0)
		{
			init_flag = true;
		}
		else
		{
			init_flag = false;
		}
	}
}




void RecordClass::start(unsigned short *filename){
	ard_record_start(_st);
	ard_record_getfilename(filename);
}



void RecordClass::pause(){
	ard_record_pause(_st);
}

void RecordClass::resume(){
	ard_record_resume(_st);
}

void RecordClass::stop(void){
	ard_record_stop(_st);
}

RecordStatus RecordClass::getStatus(){
	if(init_flag)
		return (RecordStatus)ard_record_getStatus(_st);
	else
		return RECORD_INIT;
}

void RecordClass::end(void){
	ard_record_stop(_st);
	ard_record_end(_st);
	init_flag = false;
}

RecordClass::operator bool() {
  return init_flag;
}

RecordClass Record;




