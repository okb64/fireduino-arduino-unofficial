/*
 * ard_record.h
 *
 *  Created on: 2016年9月19日
 *      Author: huangab
 */

#ifndef ARDUINO_LIB_ARD_RECORD_H_
#define ARDUINO_LIB_ARD_RECORD_H_

#ifdef __cplusplus
extern "C" {
#endif

extern int ard_record_init(unsigned char as);
extern int ard_record_start(unsigned char as);
extern int ard_record_pause(unsigned char as);
extern int ard_record_resume(unsigned char as);
extern int ard_record_stop(unsigned char as);
extern int ard_record_getStatus(unsigned char as);
extern int ard_record_end(unsigned char as);
extern int ard_record_getfilename(unsigned short *filename);

#ifdef __cplusplus
}
#endif

#endif /* ARDUINO_LIB_ARD_RECORD_H_ */
