/*
 * ard_test.h
 *
 *  Created on: 2016年8月31日
 *      Author: huangab
 */

#ifndef ARDUINO_LIB_ARD_TEST_H_
#define ARDUINO_LIB_ARD_TEST_H_

#ifdef __cplusplus
extern "C" {
#endif

extern int test_or_aging;

// get systick count value
extern int ard_record_start(void);
extern int ard_record_stop(void);
extern int ard_linein_start(int ch);
extern int ard_linein_stop(void);
extern void ard_wifi_apptask_create(unsigned char *ssid,int ssid_length,unsigned char *passwd,int passwd_length,unsigned char *url);
extern int ard_test_or_aging(void);

#ifdef __cplusplus
}
#endif


#endif /* ARDUINO_LIB_ARD_TEST_H_ */
