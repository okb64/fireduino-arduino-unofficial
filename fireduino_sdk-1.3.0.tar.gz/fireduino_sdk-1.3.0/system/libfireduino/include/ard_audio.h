 /**
 * @file ard_audio.h
 * @brief Definitions audio driver header for Fireduino
 * @author jiang<jdz@t-chip.com.cn>
 * @version V1.0
 * @date 2016.02
 *
 * @par Copyright:
 * Copyright (c) 2016 T-CHIP INTELLIGENCE TECHNOLOGY CO.,LTD. \n\n
 *
 * For more information, please visit website <http://www.t-firefly.com/>, \n\n
 * or email to <service@t-firefly.com>.
 */

#ifndef _ARDUINO_ADUIO_H_
#define _ARDUINO_ADUIO_H_


#ifdef __cplusplus
extern "C" {
#endif

extern int ard_audio_init(unsigned char as);
extern int ard_audio_playfile(unsigned char as,const wchar_t*path);
extern int ard_audio_playnetfile(unsigned char as,const char *path);
extern int ard_audio_setVolume(unsigned char as,unsigned char vol);
extern unsigned char ard_audio_getVolume(unsigned char as);
extern int ard_audio_pause(unsigned char as);
extern int ard_audio_resume(unsigned char as);
extern int ard_audio_stop(unsigned char as);
extern int ard_audio_getStatus(unsigned char as);
extern int ard_audio_end(unsigned char as);

#ifdef __cplusplus
}
#endif


#endif
