#!/bin/sh
#set -e

echo "starting upload script"
#echo "Args to shell:" $*
#
# ARG 1: Path to this script.
# ARG 2: Bin File to upload
#

mydir="$1"
binfile="${2}"
firmware="${binfile%%.bin}".img
upgrade_tool=./mac_upgrade_tool.app/Contents/MacOS/mac_upgrade_tool
sleep="sleep"

function fatal() {
    echo
    echo "$1"
    shift
    echo "$@"
    exit 1
}

cd "$mydir"

echo
echo "------------"
echo "Packaging..."
echo "------------"
RESULT=$(./update_tool \
             --path "${binfile}" \
             --res "./Menu.res" \
             --firmware "./fwtmp" \
             --uis "./image.uis" \
             --masterversion "0" \
             --slaveversion "1" \
             --smallversion "11" 2>&1 \
             && ./rkImageMaker -RKSMART RockMedia.res fwtmp ${firmware} 2>&1 \
             && rm -f fwtmp ) \
    || fatal "Package failed:" "$RESULT"
echo "done"

"$sleep" 1

echo
echo "------------"
echo "Uploading..."
echo "------------"

count=0
while true; do
    echo -en '>'
    ((count=count+1))
    if [[ $count -gt 40 ]]; then
        echo
    fi
    "$sleep" 0.5
done &
dot_pid=$!

RESULT=$("$upgrade_tool" UF "${firmware}" 2>&1)

if [[ $? -ne 0 ]]; then
    kill $dot_pid
    fatal "Upgrade failed:" "$RESULT"
else
    kill $dot_pid
    echo -e "\ndone"
fi
