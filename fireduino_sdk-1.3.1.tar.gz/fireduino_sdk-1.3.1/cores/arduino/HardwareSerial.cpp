 /**
 * @file HardwareSerial.c
 * @brief Definitions HardwareSerial class for Fireduino
 * @author jiang<jdz@t-chip.com.cn> 
 * @version V1.0
 * @date 2016.02
 * 
 * @par Copyright:
 * Copyright (c) 2016 T-CHIP INTELLIGENCE TECHNOLOGY CO.,LTD. \n\n
 *
 * For more information, please visit website <http://www.t-firefly.com/>, \n\n
 * or email to <service@t-firefly.com>.
 */ 
#include "HardwareSerial.h"
//#include "DriverInclude.h"
#include "ard_uart.h"
#include "USBSerial.h"

// SerialEvent functions are weak, so when the user doesn't define them,
// the linker just sets their address to 0 (which is checked below).
// The Serialx_available is just a wrapper around Serialx.available(),
// but we can refer to it weakly so we don't pull in the entire
// HardwareSerial instance if the user doesn't also refer to it.
#if defined(HAVE_HWSERIAL0)
  void serialEvent() __attribute__((weak));
#endif
#if defined(HAVE_HWSERIAL1)
  void serialEvent1() __attribute__((weak));
  bool Serial1_available() __attribute__((weak));
#endif

#if defined(HAVE_HWSERIAL2)
  void serialEvent2() __attribute__((weak));
  bool Serial2_available() __attribute__((weak));
#endif

HardwareSerial::HardwareSerial(unsigned char  dev) {
	dev_id = dev;
}

void HardwareSerial::begin(uint32_t baud)
{
	begin(baud,SERIAL_8N1);
}

void HardwareSerial::begin(uint32_t baud, uint8_t config) 
{
	uint8_t databit = (config >> 0) & 0x0F;
	uint8_t stopbit = (config >> 4) & 0x01;
	uint8_t parity  = (config >> 5) & 0x03;
	ard_uart_init((uint8_t)dev_id,baud ,databit,stopbit,parity);
}

void HardwareSerial::end(void) 
{
	ard_uart_disable(dev_id);
}

int HardwareSerial::read(void) 
{
	while(! this->available());

	return ard_uart_getc(dev_id);
}

int HardwareSerial::available(void) 
{
	return ard_uart_data_available(dev_id);
}


int HardwareSerial::peek(void)
{
	return ard_uart_peek(dev_id);
}

int HardwareSerial::availableForWrite(void)
{
  return 1;
}

size_t HardwareSerial::write(unsigned char ch) {
	return ard_uart_putc(dev_id,ch);
}

void HardwareSerial::flush(void) {

	ard_uart_flush(dev_id);
}

HardwareSerial Serial2(1);
HardwareSerial Serial1(2);

void serialEventRun(void)
{
#if defined(HAVE_HWSERIAL0)
  if (Serial0_available && serialEvent && Serial0_available()) serialEvent();
#endif
#if defined(HAVE_HWSERIAL1)
  if (Serial1_available && serialEvent1 && Serial1_available()) serialEvent1();
#endif
#if defined(HAVE_HWSERIAL2)
  if (Serial2_available && serialEvent2 && Serial2_available()) serialEvent2();
#endif
}

// Function that can be weakly referenced by serialEventRun to prevent
// pulling in this file if it's not otherwise used.
bool Serial1_available() {
  return Serial1.available();
}

bool Serial2_available() {
  return Serial2.available();
}

