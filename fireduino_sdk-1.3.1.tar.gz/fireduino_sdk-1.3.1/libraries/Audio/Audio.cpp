
#include <ard_audio.h>
#include <string.h>
#include <wchar.h>
#include "Audio.h"

void AudioClass::begin(Audio_Source as){
	if(init_flag == false)
	{
		_st = as;
		if(ard_audio_init(as) == 0)
		{
			init_flag = true;
		}
		else
		{
			init_flag = false;
		}
	}
}

//extern "C" unsigned int  Ascii2Unicode(unsigned char * pbAscii, unsigned short * pwUnicode, unsigned int len);
extern "C" int wchar_from_utf8(unsigned short *wbuf, int wbuf_len, const char *buf);

void AudioClass::playFile(const char *path){
	unsigned short path_t[256];
	if(_st == AUDIO_SD)
	{
		// Ascii2Unicode((unsigned char *)path,(unsigned short *)path_t,strlen(path)*2);
		// path_t[strlen(path)] = 0x0000;
		if (wchar_from_utf8(path_t, sizeof(path_t), path) > 0)
			ard_audio_playfile(_st,(wchar_t*)path_t);
	}
}

void AudioClass::playFile(const wchar_t* path){
	if(_st == AUDIO_SD)
	{
		ard_audio_playfile(_st,path);
	}
}

void AudioClass::playNetFile(const char* path)
{
	if(_st == AUDIO_NET)
	{
		ard_audio_playnetfile(_st,path);
	}
}

void AudioClass::setVolume(unsigned char volume){
	ard_audio_setVolume(_st,volume);
}

unsigned char AudioClass::getVolume(){
	return ard_audio_getVolume(_st);
}

void AudioClass::pause(){
	ard_audio_pause(_st);
}

void AudioClass::resume(){
	ard_audio_resume(_st);
}

void AudioClass::stop(){
	ard_audio_stop((unsigned char)_st);
}

AudioStatus AudioClass::getStatus(){
	if(init_flag)
		return (AudioStatus)ard_audio_getStatus((unsigned char)_st);
	else
		return AudioStop;
}

void AudioClass::end(){
	ard_audio_stop((unsigned char)_st);
	ard_audio_end(_st);
	init_flag = false;
}

AudioClass::operator bool() {
  return init_flag;
}

AudioClass Audio;

