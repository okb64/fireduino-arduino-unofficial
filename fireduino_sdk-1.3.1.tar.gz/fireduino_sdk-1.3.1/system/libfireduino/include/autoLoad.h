/*
 * autoLoad.h
 *
 *  Created on: 2016��3��16��
 *      Author: huangab
 */


#ifdef __cplusplus
extern "C" {
#endif



extern int autoLoadInit(void);
extern int autoLoadStart();

#ifdef __cplusplus
}
#endif




